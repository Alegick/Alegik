SELECT *
FROM person, pizzeria
ORDER BY person.id, pizzeria.id;
