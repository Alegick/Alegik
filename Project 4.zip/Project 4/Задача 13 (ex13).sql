-- Удаляем заказы за 25 февраля 2022
DELETE FROM person_order
WHERE order_date = '2022-02-25';

-- Удаляем "greek pizza" из меню
DELETE FROM menu
WHERE pizza_name = 'greek pizza';
